<?php

declare(strict_types=1);

require __DIR__ . '/audit.php';
